from resources.lib import kodiutils
import os
import logging
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys
import subprocess
from resources.modules.httpclient import HttpClient

logger = logging.getLogger(xbmcaddon.Addon().getAddonInfo('id'))


def panel_list(url, wait=500):
    skip = kodiutils.get_setting_as_bool("check_liste")
    if skip:
        return None

    import re
    # url_ori = url
    try:
        url = url.split(";")[0]
        if url.startswith('/thegroove/'):
            from resources.modules.thegroove.thegroove_httpclient import ThegrooveHttpClient
            httpclient = ThegrooveHttpClient()
        else:
            httpclient = HttpClient()

        try:
            base_url = re.compile(r'(http.*?://.*?/)').findall(url)[0]
        except:
            base_url = None
        try:
            username = re.compile(r'username=(.*?)(?:&|$)').findall(url)[0]
        except:
            username = None
        try:
            password = re.compile(r'password=(.*?)(?:&|$)').findall(url)[0]
        except:
            password = None
        try:
            l_type = re.compile(r'type=(.*?)(?:&|$)').findall(url)[0]
        except:
            l_type = None

        if (url.startswith('http') or (url.startswith('/thegroove/'))) and not l_type and (
                l_type != "m3u" or l_type != "m3u8"):

            r = httpclient.get_request(url, timeout=6)

            if url.startswith('http'):
                if r.status_code > 399:
                    logger.warning("panel_list: HTTP %s su %s", r.status_code, url)
                    return None
                lista = r.content
            else:
                lista = r
            
            expr = r'(http.*?//(.*?/).*?)/([\d|\d\.ts|\d\.m3u8]+)\s'
            matches = re.compile(expr, re.MULTILINE).findall(lista)

            match = matches[0][0]
            if match:
                url = match.replace("/live/", "/")
                print(url)
                expr = r'(http.*?://.*?:[\d]+/)(.*?)/(.*?)$'
                matches = re.compile(expr, re.IGNORECASE).findall(url)[0]
                base_url = matches[0]
                username = matches[1]
                password = matches[2]
                l_type = "m3u"

        if base_url and username and password and l_type:
            panel_url = base_url + "player_api.php?username=" + username + "&password=" + password + "&"

            xbmc.sleep(wait)
            r = HttpClient().get_request(panel_url, timeout=6)

            logger.debug(r.status_code)
            logger.debug(r.text)

            if r.status_code > 399:
                logger.warning("panel_list: HTTP %s su player_api.php (%s)", r.status_code, panel_url)
                return None
            info = r.json()["user_info"]

            import datetime
            try:
                expires = datetime.datetime.fromtimestamp(float(info["exp_date"])).strftime("%d/%m/%Y")
            except Exception:
                # print e.message
                expires = "-"

            return [str(info["status"]), str(info["active_cons"]), str(info["max_connections"]), str(info["auth"]),
                    expires]
        else:
            logger.warning("panel_list: dati panel incompleti (base_url=%s, username=%s, password=%s, l_type=%s)",
                            base_url, username, password, l_type)

    except Exception as e:
        logger.warning("panel_list: eccezione %s", e)
        if kodiutils.get_setting_as_bool("debug"):
            import traceback
            traceback.print_stack()
        return None


def _parse_mag_expiry(val):
    """
    Prova a interpretare un valore di scadenza restituito da get_main_info in uno dei
    formati usati dai vari portali MAG/Stalker:
      - epoch numerico (es. "1893456000")
      - data testuale ISO-like (es. "2027-05-01 00:00:00")
      - data testuale estesa in inglese (es. "June 12, 2027, 5:59 pm" - usata da hsneu.com)
    Ritorna la data formattata "dd/mm/YYYY", o None se il valore non e' riconoscibile.
    """
    import datetime

    s = str(val).strip()
    if not s or s in ("0", "0000-00-00 00:00:00"):
        return None

    try:
        return datetime.datetime.fromtimestamp(float(s)).strftime("%d/%m/%Y")
    except (ValueError, TypeError):
        pass

    try:
        return datetime.datetime.strptime(s, "%B %d, %Y, %I:%M %p").strftime("%d/%m/%Y")
    except ValueError:
        pass

    # ultima spiaggia: se inizia con una data ISO-like, prendi solo quella parte
    head = s.split(" ")[0]
    if head[:4].isdigit() and "-" in head:
        return head

    return None


def _format_mag_account_info(info):
    """
    Converte la risposta di PortalApi.get_account_info() (portali MAG/Stalker,
    action=get_main_info) nello stesso formato [status, active_cons, max_connections,
    auth, expires] restituito da panel_list() per i portali Xtream, cosi' l'XML che
    consuma il risultato (label "Utenti: X su Y | Scadenza: Z") non deve cambiare.

    I portali MAG/Stalker non espongono un concetto di "utenti connessi/massimi" via
    get_main_info come fa Xtream: quei due campi restano "-" quando non disponibili.
    """
    if not info:
        return None

    expires = None
    # "phone" e' il campo usato per la scadenza da alcuni portali (es. hsneu.com),
    # nonostante il nome fuorviante: contiene una data, non un numero di telefono.
    for key in ("expire_billing_date", "end_date", "phone_end_date", "phone"):
        val = info.get(key)
        if val is None:
            continue
        expires = _parse_mag_expiry(val)
        if expires:
            break

    if not expires:
        # Nessun campo di scadenza riconosciuto: non abbiamo nulla di utile da mostrare
        return None

    status = str(info.get("status", "-"))
    active_cons = "-"
    max_connections = "-"
    auth = "1"

    return [status, active_cons, max_connections, auth, expires]


def mac_list_check(url, wait=2000):
    from resources.modules.thegroove.portal_api import PortalApi
    import re
    try:
        portal = PortalApi(url)
        link = portal.get_link("ffmpeg%20http://localhost/ch/1823_&series=")
        logger.debug(link)
        try:
            link = link.split(" ")[1]
        except:
            pass

        expr = r'(http.*?://.*?:[\d]+/)(.*?)/(.*?)/.*?$'
        matches = re.compile(expr, re.IGNORECASE).findall(link)
        if matches:
            matches = matches[0]
            base_url = matches[0]
            username = matches[1]
            password = matches[2]
            l_type = "m3u"

            url = base_url + "get.php?username=" + username + "&password=" + password + "&type=" + l_type

            return panel_list(url, wait)

        # Formato non-Xtream (es. "...?mac=...&stream=...&play_token=..."): probabile
        # portale MAG/Stalker nativo, che non ha player_api.php. Proviamo la via
        # nativa MAG per la certificazione (scadenza abbonamento).
        logger.debug("mac_list_check: link non in formato Xtream, provo la via MAG/Stalker: %s", link)
        xbmc.sleep(wait)
        info = portal.get_account_info()
        result = _format_mag_account_info(info)
        if result is None:
            logger.warning("mac_list_check: nessun campo scadenza riconosciuto in get_account_info (link=%s) - risposta grezza: %s",
                            link, info)
        return result
    except Exception as e:
        logger.warning("mac_list_check: eccezione %s", e)
        if kodiutils.get_setting_as_bool("debug"):
            import traceback
            traceback.print_stack()
        return None


def get_cores_num():
    try:
        import multiprocessing
        return multiprocessing.cpu_count()
    except ImportError:
        pass

    try:
        res = open('/proc/cpuinfo').read().count('processor\t:')

        if res > 0:
            return res
    except IOError:
        pass

    try:
        res = int(os.environ['NUMBER_OF_PROCESSORS'])

        if res > 0:
            return res
    except (KeyError, ValueError):
        pass

    try:
        try:
            dmesg = open('/var/run/dmesg.boot').read()
        except IOError:
            dmesg_process = subprocess.Popen(['dmesg'], stdout=subprocess.PIPE)
            dmesg = dmesg_process.communicate()[0]

        res = 0
        while '\ncpu' + str(res) + ':' in dmesg:
            res += 1

        if res > 0:
            return res
    except OSError:
        pass
    return 2


def transliterate(text):
    try:
        from resources.lib.pytils import translit
        # from resources.lib.pytils.third import six
        ttext = translit.translify(text, False)

        return ttext
    except Exception as e:
        if kodiutils.get_setting_as_bool("debug"):
            import traceback
            traceback.print_exc()
            logger.debug(str(e))
        return text


def cleanup():
    import shutil
    from resources.modules.thegroove.thegroove_httpclient import ThegrooveHttpClient
    req = HttpClient().get_request(ThegrooveHttpClient().server_url + "/Thepasto/remove.php")
    json_data = req.json()

    dDialog = xbmcgui.DialogProgress()
    dDialog.create(xbmcaddon.Addon().getAddonInfo('name'), "Rimozione In Corso:")

    for i, r in enumerate(json_data):
        perc = int((i + 1) * 100 / len(json_data))
        dDialog.update(perc, "Rimozione id " + r + " " + str(i + 1) + " di " + str(len(json_data)) + "Kb")
        for p in ["profile/addon_data/", "home/addons/"]:
            p.replace("/", os.sep)
            if sys.version_info[0] > 2:
                pr = xbmcvfs.translatePath(os.path.join("special://", p, r))
            else:
                pr = xbmc.translatePath(os.path.join("special://", p, r))

            if os.path.isdir(pr):
                try:
                    shutil.rmtree(pr, ignore_errors=False)
                except:
                    pass

    dDialog.close()


def get_version():
    import xml.etree.ElementTree as ET
    if sys.version_info[0] > 2:
        root = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('Path'))
    else:
        root = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('Path'))
    addon = os.path.join(root, "addon.xml")

    root = ET.parse(open(os.path.join(addon), "r")).getroot()
    return root.attrib["version"]


def get_revision(attr):
    import json
    if sys.version_info[0] > 2:
        root = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('Path'))
    else:
        root = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('Path'))
    with open(os.path.join(root, 'thegroove_version.json'), 'r') as f:
        version = json.load(f)
        f.close()

    return version[attr]


def get_zeronet_page(page):
    if page.startswith("http://127.0.0.1:43110"):
        zurl = kodiutils.get_setting("zeronet_url")
        if zurl and zurl != "":
            page = page.replace("http://127.0.0.1:43110", "http://" + zurl)

    return page
