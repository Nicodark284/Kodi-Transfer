from datetime import datetime

import logging
import requests
import math
import re

import xbmcaddon

from resources.lib import kodiutils
from resources.modules import bypass_dns

try:
    from urllib.parse import quote as quoter
    from urllib.parse import unquote as unquoter
    from urllib.parse import urlparse, urlsplit
    from urllib.parse import parse_qs

except ImportError:
    from urllib import quote as quoter
    from urllib import unquote as unquoter

logger = logging.getLogger(xbmcaddon.Addon().getAddonInfo('id'))

# UA MAG "storico": molti portali Stalker verificano la firma del device e
# rispondono solo a questa (o simile). Resta il default, ma ora è sovrascrivibile.
DEFAULT_MAG_UA = ('Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp '
                   'ver: 2 rev: 250 Safari/533.3 ')


class PortalApi:

    def __init__(self, url, mac=None, user_agent=None, use_bypass=None, timeout=None, **kwargs):

        self.params = []

        if not mac:
            match = re.compile(r'(.*?)\?(.*?)($|(&.*?$))', re.MULTILINE).findall(url)[0]
            url = match[0]
            mac = match[1]
            try:
                self.params = re.compile(r'([^&?]*?)=([^&?]*)').findall(match[2])
            except:
                pass

        # ([^&?]*?)=([^&?]*)
        self.url = url
        self.mac = mac
        self.api_url = self.url + "/portal.php?"

        # Sovrascrivibili per-istanza (es. dal pyFunction di una lista specifica):
        #   PortalApi(page, user_agent="...", use_bypass=True, timeout=8)
        self.user_agent = user_agent or DEFAULT_MAG_UA
        self.use_bypass = kodiutils.get_setting_as_bool("use_bypass_dns") if use_bypass is None else use_bypass
        # Prima era fisso a 1s: causa quasi certa dei fallimenti intermittenti.
        self.timeout = timeout or 6

        self.__dict__.update(**kwargs)
        self.token = ""
        self.request_headers = None
        self.types = ["Live", "VOD", "All"]

    def root(self):
        ret = []
        for st in self.types:
            ret.append((st, self.url + "?" + self.mac))
        return ret

    def set_headers(self):
        self.request_headers = {
            'User-Agent': self.user_agent,
            'X-User-Agent': 'Model: MAG250; Link: WiFi',
            'Connection': 'keep-Alive',
            'Cookie': 'mac=' + quoter(self.mac) + "; stb_lang=en; timezone=Europe%2Amsterdam;",
            'Pragma': 'no-cache',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'gzip'
        }
        if self.token != "":
            self.request_headers['Authorization'] = 'Bearer ' + self.token

    def get_token(self):
        # req = requests.get(self.api_url + "type=stb&action=handshake&token=", headers=self.request_headers)
        res = self.do_request("type=stb&action=handshake")
        if not res or "token" not in res:
            logger.warning("PortalApi get_token: handshake fallito o senza 'token' (url=%s, res=%s)",
                            self.api_url, res)
            self.token = ""
            return
        token = res["token"]
        self.token = token
        self.get_profile()

    def get_profile(self):
        # self.request_headers['Authorization'] = 'Bearer ' + self.token
        dt = datetime.now()
        timestamp = datetime.timestamp(dt)
        p = 'type=stb&action=get_profile&hd=1&ver=ImageDescription: 0.2.18-r23-254; ImageDate: Wed Oct 31 15:22:54 ' \
            'EEST 2018; PORTAL version: 5.5.0; API Version: JS API version: 343; STB API version: 146; Player Engine ' \
            'version: 0x58c&num_banks=2&sn=17F88C9910EF5&client_type=STB&image_version=218&video_out=hdmi&device_id' \
            '=F48C7788EF17D24F661C5A1782DF0D2237D545BE12A5A4B4325D89A52A7DF186&device_id2' \
            '=F48C7788EF17D24F661C5A1782DF0D2237D545BE12A5A4B4325D89A52A7DF186&signature' \
            '=845519FCE3386C1847AD3469AAD6D2773080C6F94CB59CD0A9E82605FAEDE02F&auth_second_step=1&hw_version=2.6-IB' \
            '-00&not_valid_token=0&metrics={"mac":"' + \
            self.mac + '","sn":"17F88C9910EF5","type":"STB",' \
                       '"model":"MAG254",' \
                       '"uid":"F48C7788EF17D24F661C5A1782DF0D2237D545BE12A5A4B4325D89A52A7DF186",' \
                       '"random":""}&hw_version_2=aff4d6ab1ab4e0660f09f89809c6e9782fa43263&timestamp=' \
            + str(timestamp) + '&api_signature=262 '
        self.do_request(p)
        res = self.do_request("type=stb&action=get_profile")
        # print(res)
        return res

    def get_categories(self, ltype="live"):
        self.get_token()
        url = "type=itv&action=get_genres" if ltype == "live" else "type=vod&action=get_categories"
        res = self.do_request(url, True)
        # print(res)
        if res:
            ret = []
            for gen in res:
                if "all" == gen["title"].encode('utf-8', errors='ignore').lower().decode():
                    continue
                ret.append(
                    (gen["id"], gen["title"].encode('utf-8', errors='ignore').decode(), self.url + "?" + self.mac))

            # print(ret)
            return ret

    def get_itv_genres(self):
        # self.request_headers['Authorization'] = 'Bearer ' + self.token
        return self.get_categories()

    def get_vod_genres(self):
        # self.request_headers['Authorization'] = 'Bearer ' + self.token
        return self.get_categories("vod")

    def get_genres(self):
        self.get_token()
        res = self.do_request("type=itv&action=get_genres", True)
        # print(res)

        ret = {}
        for g in res:
            ret[g["id"]] = {"title": g["title"], "alias": g["alias"]}

        return ret

    def get_all_channels(self):
        # self.request_headers['Authorization'] = 'Bearer ' + self.token
        self.get_token()
        # self.get_profile()
        res = self.do_request("type=itv&action=get_all_channels")
        # print(res)
        genres = self.get_genres()

        ret = []

        for i in res["data"]:
            id = i["id"]
            number = i["number"]
            name = i["name"]
            cmd = i['cmd']
            logo = i["logo"]
            tmp = i["use_http_tmp_link"]
            genre_id = i["tv_genre_id"]
            try:
                genre_title = genres[genre_id]['title']
            except:
                genre_title = ""

            try:
                cmd = cmd.split(" ")[1]
            except:
                pass

            ret.append((id, number, name, cmd, logo, tmp, genre_title))
        return ret

    def get_ordered_list(self, id_genre, ltype="live", check=False):
        self.get_token()
        if ltype == "live":
            url = "type=itv&action=get_ordered_list&genre=" + str(id_genre)
        else:
            url = "type=vod&action=get_ordered_list&genre=" + str(id_genre)
        url += "&force_ch_link_check=&fav=0&sortby=number&hd=0"

        tot_pages = 0
        page = 1

        ret = []

        while True:
            res = self.do_request(url + "&p=" + str(page), True)
            # print(res)
            if res and "data" in res:

                for ch in res["data"]:
                    # strm_url = ch["cmd"].replace("ffmpeg", "").strip()

                    ret.append((ch["name"], ch["cmd"]))

            if tot_pages == 0:
                tot_pages = math.ceil(int(res["total_items"]) / int(res["max_page_items"]))

            page += 1

            if page > tot_pages or check:
                break

        # print(ret)
        return ret

    def get_itv_list(self, id_genre):
        return self.get_ordered_list(id_genre)

    def get_vod_list(self, id_categ):
        return self.get_ordered_list(id_categ, "vod")

    def get_account_info(self):
        """
        Info abbonamento via portal.php (action=get_main_info), disponibile su molti
        portali MAG/Stalker che NON espongono un player_api.php in stile Xtream.
        Riusa il token già ottenuto se presente (es. da una get_link() precedente
        sulla stessa istanza), altrimenti fa l'handshake.
        """
        if not self.token:
            self.get_token()
        return self.do_request("type=account_info&action=get_main_info")

    def get_link(self, cmd, ltype="itv"):
        self.get_token()

        url = "type=" + ltype + "&action=create_link&cmd=" + cmd
        url += "&series=0&forced_storage=false&disable_ad=false&download=false&force_ch_link_check=false"

        res = self.do_request(url, True)
        if res:
            if res["id"].isdigit():
                link = res["cmd"]
            else:
                try:
                    strm_id = re.compile(r".*?/([\d]+(?:\.ts|$))").findall(res["id"])[0]
                    base = re.compile(r"(http.*?://.*?:[\d]+(?:/live/|/).*?/.*?/).*?(\?.*?)$").findall(res["cmd"])[0]
                    link = base[0] + strm_id + base[1]

                except Exception as e:
                    logger.warning("PortalApi get_link: parsing id/cmd fallito (id=%s, cmd=%s): %s",
                                    res.get("id"), res.get("cmd"), e)
                    link = cmd
        else:
            logger.warning("PortalApi get_link: create_link senza risposta valida (url=%s, cmd=%s) - uso fallback",
                            self.api_url, cmd)
            link = cmd

        try:
            link = link.split(" ")[1]
        except:
            pass

        # link = re.sub(r"(http.*?//.*?:[\d]+)", self.url, link, 0, re.MULTILINE)
        params = ""
        if self.params:
            for par in self.params:
                params += "=".join(par) + "&"

        params = params.strip("&")

        if "User-Agent" not in params:
            params += "!User-Agent=Lavf53.32.100"
        if "Icy-MetaData" not in params:
            params += "&Icy-MetaData=1"

        return link + "|" + params

    def do_request(self, url, is_get=False):
        self.set_headers()
        request_url = self.api_url + url + "&JsHttpRequest=1-xml"

        parsed_url = urlparse(request_url)
        payload = parse_qs(parsed_url.query)
        # print(payload)

        res = None
        try:
            if is_get:
                res = requests.get(self.api_url, headers=self.request_headers, params=payload,
                                    timeout=self.timeout)
            else:
                res = requests.post(self.api_url, headers=self.request_headers, data=payload,
                                     timeout=self.timeout)

            if res.status_code > 399:
                logger.warning("PortalApi do_request: HTTP %s su %s (action=%s)", res.status_code,
                                self.api_url, url)
                res = None
        except Exception as e:
            logger.debug("PortalApi do_request diretta fallita: %s", e)
            res = None

        # Fallback: richiesta diretta fallita (timeout/connessione/DNS) e bypass attivo.
        # Riusa il motore di bypass_dns.py (DoH+SNI, poi rotazione proxy) già presente
        # nell'addon per le sorgenti esterne — ora copre sia GET che POST, quindi
        # anche handshake/get_profile/get_all_channels (che sono POST) sono coperte.
        if res is None and self.use_bypass:
            try:
                text = bypass_dns.request_with_bypass(
                    self.api_url,
                    method="GET" if is_get else "POST",
                    headers=self.request_headers,
                    params=payload if is_get else None,
                    data=None if is_get else payload,
                    timeout=self.timeout,
                )
                if text:
                    res = bypass_dns._MockResponse(text)
                else:
                    logger.warning("PortalApi do_request: bypass senza risposta su %s (action=%s)",
                                    self.api_url, url)
            except Exception as e:
                logger.debug("PortalApi do_request bypass fallita: %s", e)

        if res is None:
            return None

        try:
            jres = res.json()
        except Exception as e:
            logger.warning("PortalApi do_request: risposta non-JSON su %s (action=%s): %s", self.api_url, url, e)
            return None

        if "js" in jres:
            return jres["js"]
        else:
            logger.warning("PortalApi do_request: risposta senza campo 'js' (action=%s): %s", url, jres)
            return None
