import inspect
import json
import logging
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from resolver_360 import SportResolver

logger = logging.getLogger(__name__)


class CommonResolver:

    def __init__(self, resolver: 'SportResolver'):
        self.servers = self.set_servers()
        self.resolver = resolver
        self.page_url = None
        self.page_src = None
        self.request_headers = {}
        self.set_request_headers()
        self.use_last_domain = False

    def set_request_headers(self):
        pass

    def set_page_url(self, url):
        self.page_url = url

    def set_page_src(self, page_src):
        self.page_src = page_src

    def set_servers(self):
        try:
            fpath = inspect.getfile(self.__class__)
            jsonf = re.sub(r"^(.*?\.)(py)$", "\\1json", fpath, 0, re.DOTALL)
            with open(jsonf, 'r', encoding='utf-8') as f:
                data = json.load(f)
            domains = data.get("domains") if isinstance(data, dict) else None
            if isinstance(domains, list):
                return domains
            # json vuoto/null o senza "domains" (es. supervideo.json): niente
            # domini, quindi il resolver non verra' mai selezionato. Prima
            # veniva stampato un traceback ad ogni risoluzione.
            logger.warning("%s: json senza 'domains' (%r), resolver disattivato",
                           self.__class__.__name__, data if data is None else type(data).__name__)
            return []
        except FileNotFoundError:
            logger.debug("%s: nessun file json dei domini", self.__class__.__name__)
            return []
        except Exception as E:
            logger.warning("%s: impossibile leggere i domini: %s", self.__class__.__name__, E)
            return []

    def find_page(self):
        pass

    def find_page_src(self, src):
        pass

    def parse_stream(self, url):
        pass

    def set_referer(self, url):
        pass

    def find_stream(self):
        pass
