import re
import json
from urllib.parse import quote_plus

from conf.common import CommonResolver


class Vixsrc(CommonResolver):
    def __init__(self, resolver):
        super().__init__(resolver)

    def find_stream(self):
        api_url = self.page_url.replace("/movie/", "/api/movie/").replace("/tv/", "/api/tv/")
        
        try:
            response = self.resolver.cli.get_request(api_url)
            data = json.loads(response.text)
            embed_path = data.get("src", "")
            if not embed_path:
                return []
            
            embed_url = f"https://vixsrc.to{embed_path}"
            embed_res = self.resolver.cli.get_request(embed_url)
            source_text = embed_res.text
        except:
            source_text = self.page_src

        ms = re.compile(r"window.masterPlaylist = ({.*?params:.*?{.*?},.*?})", re.DOTALL) \
            .findall(source_text)

        canPlayFHD = re.compile(r"window\.canPlayFHD = (.*?)\s", re.DOTALL).findall(source_text)

        if ms:
            masterplaylist = ms[0]
            mediaurl_match = re.compile(r"url: '([^']+)'", re.MULTILINE).findall(masterplaylist)
            
            if not mediaurl_match:
                return []
                
            mediaurl = mediaurl_match[0]
            mediaurl += "&" if "?" in mediaurl else "?"
            
            ps = re.compile(r".*?'([^']+)':.*?'(.*?)'(?:,|$)", re.MULTILINE | re.DOTALL).findall(masterplaylist)
            for k, v in ps:
                if v:
                    mediaurl += f"{k}={v}&"
            
            mediaurl = mediaurl.rstrip("&")

            if canPlayFHD and canPlayFHD[0] == "true":
                mediaurl += "&h=1"

            mediaurl += "&lang=it"

            return [mediaurl]

        return []

    def set_referer(self, url):
        return "!Referer=" + quote_plus(self.page_url) + "&User-Agent=" + self.resolver.cli.headers[
            "user-agent"] + "&force_isaf=1&isaf_rts=false"
