import re
from jsbeautifier.unpackers import packer
from conf.common import CommonResolver


class Dropload(CommonResolver):

    def __init__(self, resolver):
        super().__init__(resolver)

    def find_stream(self):
        packed_src = re.compile(r'(eval\(function\(p,a,c,k,e,d\).*?)</script>', re.DOTALL).findall(self.page_src)
        unpacked_src = packer.unpack(packed_src[0]) #BOH
        stream = re.compile(r'file:\"([^\"]+)\"', re.DOTALL).findall(unpacked_src)

        if stream:
            return [stream[0]]
            
        return []
        
    def set_referer(self, url):
        ua = self.resolver.cli.headers["user-agent"]
        ref = self.resolver.find_hostname(self.resolver.stack[-1])
        return "!Referer=" + ref + "&Origin=" + ref[:-1] + "&User-Agent=" + ua
    