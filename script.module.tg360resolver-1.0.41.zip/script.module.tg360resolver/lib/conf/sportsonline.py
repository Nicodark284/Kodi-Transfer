import re
import base64
import json
import math
from urllib.parse import urlparse, urljoin
from conf.common import CommonResolver

class SportsOnline(CommonResolver):

    def __init__(self, resolver):
        super().__init__(resolver)
        self.ref = None

    def find_stream(self):
        iframe_url = self._extract_iframe_src(self.page_src, base_url=None)
        if not iframe_url:
            return []

        res1 = self.resolver.cli.get_request(iframe_url)
        self.ref = res1.url

        url = self._find_m3u8_direct(res1.text)
        if url:
            return [("Video", url)]

        url = self._decode_econfig_from_page(res1.text)
        if url:
            return [("Video", url)]

        iframe_url2 = self._extract_iframe_src(res1.text, base_url=res1.url)
        if not iframe_url2:
            return []

        res2 = self.resolver.cli.get_request(iframe_url2)
        self.ref = res2.url

        url = self._find_m3u8_direct(res2.text)
        if url:
            return [("Video", url)]

        url = self._decode_econfig_from_page(res2.text)
        if url:
            return [("Video", url)]

        return []

    def set_referer(self, url):
        parsed = urlparse(self.ref)
        origin = "{0}://{1}".format(parsed.scheme, parsed.netloc)
        ua = self.resolver.cli.headers["user-agent"]
        return "!Referer={0}&Origin={1}&User-Agent={2}".format(self.ref, origin, ua)

    @staticmethod
    def _extract_iframe_src(html, base_url):
        m = re.findall(r'<iframe[^>]+\bsrc\s*=\s*["\']([^"\']+)["\']', html, re.IGNORECASE | re.DOTALL)
        if not m:
            return None
        src = m[-1].strip()
        if src.startswith("//"):
            return "https:" + src
        if src.startswith("/") and base_url:
            return urljoin(base_url, src)
        if not src.startswith("http") and base_url:
            return urljoin(base_url, src)
        return src

    @staticmethod
    def _find_m3u8_direct(html):
        m = re.search(r'["\'](\s*https?://[^"\']+\.m3u8[^"\']*)["\']', html, re.IGNORECASE)
        return m.group(1).strip() if m else None

    @staticmethod
    def _decode_econfig_from_page(html):
        m = re.search(r"""window\._econfig\s*=\s*['"]([A-Za-z0-9+/=]+)['"]""", html)
        if not m:
            return None
        return SportsOnline._decode_econfig(m.group(1))

    @staticmethod
    def _decode_econfig(b64_str):
        def _atob(s):
            if isinstance(s, (bytes, bytearray)):
                s = s.decode('latin-1')
            clean = re.sub(r'[^A-Za-z0-9+/=]', '', s)
            if not clean:
                return b''
            pad = (4 - len(clean) % 4) % 4
            return base64.b64decode(clean + '=' * pad)

        try:
            decoded = _atob(b64_str).decode('latin-1')
            n = len(decoded)
            chunk_size = math.ceil(n / 4)

            parts = [decoded[i * chunk_size:(i + 1) * chunk_size] for i in range(4)]

            perm = [2, 0, 3, 1]
            slots = [None] * 4
            for i in range(4):
                modified = parts[i][:3] + parts[i][4:]
                slots[perm[i]] = _atob(modified)

            joined = b''.join(slots).decode('latin-1')
            config = json.loads(_atob(joined).decode('utf-8'))

            for key in ('stream_url', 'stream_url_nop2p', 'src', 'url', 'file', 'hls', 'source'):
                val = config.get(key, '')
                if isinstance(val, str) and val.startswith('http'):
                    return val

            for val in config.values():
                if isinstance(val, str) and val.startswith('http'):
                    return val

        except Exception:
            pass

        return None
