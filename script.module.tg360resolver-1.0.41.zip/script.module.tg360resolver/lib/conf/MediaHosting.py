import re
from conf.common import CommonResolver

class MediaHosting(CommonResolver):
    def __init__(self, resolver):
        self.resolver = resolver
        self.page_src = ""
        
        self.servers = ["mediahosting.space"]
        self.request_headers = {}
        self.use_last_domain = False

    def find_stream(self):
        
        found_m3u8 = re.findall(r'["\'](http.*?\.m3u8.*?)["\']', self.page_src, re.I)
        if found_m3u8:
            return found_m3u8

        
        js_sources = re.findall(r'(?:source|file|url|src)\s*[:=]\s*["\']([^"\']+\.m3u8[^"\']*)["\']', self.page_src, re.I)
        return js_sources if js_sources else []

    def set_referer(self, url):
        
        ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        return "!User-Agent=" + ua + "&Referer=https://mediahosting.space/&Origin=https://mediahosting.space"
