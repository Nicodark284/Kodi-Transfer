import re
import base64
from conf.common import CommonResolver

class BolaLoca(CommonResolver):

    def __init__(self, resolver):
        super().__init__(resolver)
        self.ref = None

    def find_stream(self):
        iframe = re.compile(r'<iframe.*?src=\"([^\"]+)\"', re.MULTILINE).findall(self.page_src)
        
        if not iframe:
            return []
            
        iframe_url = iframe[0]
        if iframe_url.startswith("//"):
            iframe_url = "https:" + iframe_url
            
        headers = {
            "Referer": "https://bolaloca.my/",
            "User-Agent": self.resolver.cli.headers["user-agent"]
        }
        
        res = self.resolver.cli.get_request(iframe_url, headers=headers)
        self.ref = res.url
        
        if "super editable" in res.text:
            return []

        stream = re.compile(r'["\'](http[^\s"\']+(?::\d+)?/hls/[^\s"\']+\.m3u8(?:\?[^\s"\']+)?)["\']').findall(res.text)
        
        if not stream:
            stream = re.compile(r'file\s*:\s*["\'](http.*?\.m3u8.*?)["\']').findall(res.text)

        if stream:
            return [("Video", stream[0])]

        return []

    def set_referer(self, url):
        ua = self.resolver.cli.headers["user-agent"]
        referer = self.ref if self.ref else "https://doubttooth.net/"
        return "|Referer=" + referer + "&Origin=https://doubttooth.net&User-Agent=" + ua
