"""
    Dailymotion resolver per tg360resolver
    Adattato dal plugin ResolveURL originale di gujal
"""

import json
import re

from conf.common import CommonResolver


class Dailymotion(CommonResolver):

    def __init__(self, resolver):
        super().__init__(resolver)

    def set_request_headers(self):
        ua = self.resolver.cli.get_random_ua()
        self.request_headers = {
            'User-Agent': ua,
            'Origin': 'https://www.dailymotion.com',
            'Referer': 'https://www.dailymotion.com/',
        }

    def _get_media_id(self):
        """Estrae il media_id dall'URL della pagina corrente."""
        pattern = r'(?:dailymotion\.com|dai\.ly)(?:/(?:video|embed|sequence|swf|player)(?:/video|/full)?)?/(?:[a-z0-9]+\.html\?video=)?(?!playlist)([0-9a-zA-Z]+)'
        m = re.search(pattern, self.page_url or '')
        if m:
            return m.group(1)
        # Prova anche dalla sorgente della pagina (es. embedded iframe)
        m = re.search(r'dailymotion\.com/(?:embed/video|video)/([0-9a-zA-Z]+)', self.page_src or '')
        if m:
            return m.group(1)
        return None

    def find_stream(self):
        media_id = self._get_media_id()
        if not media_id:
            return []

        api_url = 'https://www.dailymotion.com/player/metadata/video/{}'.format(media_id)
        r = self.resolver.cli.get_request(api_url, headers=self.request_headers)

        try:
            js_result = json.loads(r.text)
        except Exception:
            return []

        if js_result.get('error'):
            return []

        quals = js_result.get('qualities')
        if not quals:
            return []

        auto_list = quals.get('auto', [])
        if not auto_list:
            return []

        manifest_url = auto_list[0].get('url')
        if not manifest_url:
            return []

        # Recupera il manifest m3u8 e cerca la migliore sorgente progressiva
        mb = self.resolver.cli.get_request(manifest_url, headers=self.request_headers)
        sources = re.findall(
            r'NAME="(?P<label>[^"]+)".*?(?:,PROGRESSIVE-URI="|\n)(?P<url>[^\n#]+)',
            mb.text,
            re.DOTALL
        )

        if sources:
            # Ordina per risoluzione decrescente e prendi la migliore
            def _res(label):
                m = re.search(r'(\d+)', label)
                return int(m.group(1)) if m else 0

            sources_sorted = sorted(sources, key=lambda x: _res(x[0]), reverse=True)
            best_url = sources_sorted[0][1].strip()
            return [best_url]

        # Fallback: restituisci direttamente il manifest HLS
        return [manifest_url]
