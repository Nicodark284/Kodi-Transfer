"""
lib/conf/tv247.py
~~~~~~~~~~~~~~~~~
Resolver per tv247us.live


"""

from __future__ import unicode_literals

__version__ = '2.0'

import re
import json

from conf.common import CommonResolver

# ── Costanti ──────────────────────────────────────────────────────────────────

API_BASE   = 'https://chat.cfbu247.sbs/api/resolve-dlstream/{channel_id}'
REFERER    = 'https://tv247us.live/'
USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
              'AppleWebKit/537.36 (KHTML, like Gecko) '
              'Chrome/124.0.0.0 Safari/537.36')

HEADERS_API = {
    'User-Agent': USER_AGENT,
    'Referer'   : REFERER,
    'Origin'    : 'https://tv247us.live',
    'Accept'    : 'application/json',
}

# ── Mapping slug → channel_id ─────────────────────────────────────────────────

CHANNELS = {
    # USA NEWS
    'cnn-usa'              : '345',
    'fox-news'             : '347',
    'msnbc'                : '327',
    'cnbc-usa'             : '309',
    'headline-news'        : '323',
    'newsmax-usa'          : '613',
    'newsnation-usa'       : '292',
    # USA SPORT
    'espn-usa'             : '44',
    'espn2-usa'            : '45',
    'espnu-usa'            : '316',
    'fox-sports-1-usa'     : '39',
    'fox-sports-2-usa'     : '758',
    'nfl-network'          : '405',
    'nfl-redzone'          : '667',
    'nba-tv-usa'           : '404',
    'mlb-network-usa'      : '399',
    'nhl-network-usa'      : '663',
    'golf-channel-usa'     : '318',
    'tennis-channel'       : '40',
    'cbs-sports-network'   : '308',
    'acc-network-usa'      : '664',
    'sec-network-usa'      : '385',
    'big-ten-network-btn-usa': '397',
    'altitude-sports'      : '923',
    'nesn-usa'             : '762',
    'yes-network-usa'      : '763',
    'msg'                  : '765',
    'sportsnet-new-york-sny': '759',
    'marquee-sports-network': '770',
    'spectrum-sportsnet-la': '764',
    'root-sports-northwest': '920',
    'space-city-home-network': '921',
    'monumental-sports-network': '778',
    'chicago-sports-network': '776',
    'nbc-sports-philadelphia': '777',
    'nbc-sports-bay-area'  : '753',
    'nbc-sports-boston'    : '754',
    'nbc-sports-california': '755',
    'tudn-usa'             : '66',
    'espn-deportes'        : '375',
    'fox-deportes-usa'     : '643',
    'goltv-usa'            : '597',
    'willow-cricket'       : '346',
    'willow-xtra'          : '598',
    'wwe-network'          : '376',
    'mavtv-usa'            : '646',
    # USA ENTERTAINMENT
    'abc-usa'              : '51',
    'cbs-usa'              : '52',
    'nbc-usa'              : '53',
    'fox-usa'              : '54',
    'cw-usa'               : '300',
    'hbo-usa'              : '321',
    'hbo2-usa'             : '689',
    'showtime-usa'         : '333',
    'starz'                : '335',
    'cinemax-usa'          : '374',
    'tnt-usa'              : '338',
    'tbs-usa'              : '336',
    'usa-network'          : '343',
    'fx-usa'               : '317',
    'fxx-usa'              : '298',
    'amc-usa'              : '303',
    'bravo-usa'            : '307',
    'lifetime-network'     : '326',
    'syfy-usa'             : '373',
    'comedy-central'       : '310',
    'mtv-usa'              : '371',
    'vh1-usa'              : '344',
    'bet-usa'              : '306',
    'e-entertainment-television': '315',
    'paramount-network'    : '334',
    'tlc'                  : '337',
    'the-hallmark-channel' : '320',
    'freeform'             : '301',
    'oxygen-true-crime'    : '332',
    'investigation-discovery-id-usa': '324',
    'telemundo'            : '131',
    'univision'            : '132',
    'tv-one-usa'           : '660',
    # USA DOCUMENTARY
    'discovery-channel'    : '313',
    'history-usa'          : '322',
    'national-geographic'  : '328',
    'nat-geo-wild-usa'     : '745',
    'animal-planet'        : '304',
    'science-channel'      : '294',
    'travel-channel'       : '340',
    'smithsonian-channel'  : '603',
    'hgtv'                 : '382',
    'the-food-network'     : '384',
    # USA KIDS
    'cartoon-network'      : '339',
    'disney-channel'       : '312',
    'disney-xd'            : '314',
    'nick'                 : '330',
    'nick-jr'              : '329',
    'disney-jr'            : '652',
    'adult-swim'           : '295',
    # UK
    'bbc-one-uk'           : '356',
    'bbc-two-uk'           : '357',
    'bbc-three-uk'         : '358',
    'bbc-four-uk'          : '359',
    'bbc-news-channel-hd'  : '349',
    'itv-1-uk'             : '350',
    'itv-2-uk'             : '351',
    'itv-3-uk'             : '352',
    'itv-4-uk'             : '353',
    'channel-4-uk'         : '354',
    'channel-5-uk'         : '355',
    'sky-sports-football'  : '35',
    'sky-sports-main-event': '38',
    'sky-sports-premier-league': '130',
    'sky-sports-f1-1'      : '60',
    'sky-sports-cricket'   : '65',
    'sky-sports-golf-2'    : '70',
    'sky-sports-action'    : '37',
    'sky-sports-news-uk'   : '366',
    'sky-sports-tennis-2'  : '46',
    'sky-sports-racing-uk' : '554',
    'sky-sports-mix-uk'    : '449',
    'sky-atlantic'         : '362',
    'sky-max'              : '708',
    'sky-arts'             : '683',
    'sky-comedy'           : '684',
    'sky-crime'            : '685',
    'sky-history'          : '686',
    'tnt-sports-1'         : '31',
    'tnt-sports-2'         : '32',
    'tnt-sports-3'         : '33',
    'tnt-sports-4'         : '34',
    'dazn-1-uk'            : '230',
    'viaplay-sports-1'     : '451',
    'viaplay-sports-2'     : '550',
    'bbc-america'          : '305',
    'mutv-uk'              : '377',
    'liverpool-tv-lfc-tv'  : '826',
    'laligatv-uk'          : '276',
    'dave'                 : '348',
    'e4-channel'           : '363',
    # FRANCE
    'tf1-france'           : '469',
    'm6-france'            : '470',
    'france-2'             : '950',
    'france-3'             : '951',
    'canal-plus-france'    : '121',
    'canal-plus-sport-france': '122',
    'canal-plus-foot-france': '463',
    'rmc-sport-1'          : '119',
    'rmc-sport-2'          : '120',
    'bein-sports-1-france' : '116',
    'bein-sports-2-france' : '117',
    'bein-sports-3-france' : '118',
    'eurosport-1-france'   : '772',
    'eurosport-2-france'   : '773',
    'lequipe-france'       : '645',
    'canal-plus-formula-1' : '273',
    'canal-plus-motogp-france': '271',
    'bfm-tv-france'        : '957',
    'cnews-france'         : '964',
    # SPAIN
    'telecinco'            : '532',
    'tve-la-1'             : '533',
    'la-sexta-spain'       : '534',
    'cuatro-spain'         : '535',
    'movistar-laliga'      : '84',
    'movistar-liga-de-campeones': '435',
    'dazn-laliga'          : '538',
    'dazn-f1-es'           : '537',
    'dazn-1-spain'         : '445',
    'dazn-2-spain'         : '446',
    'vamos-spain'          : '521',
    'gol-play-spain'       : '530',
    'eurosport-1-spain'    : '524',
    'real-madrid-tv'       : '523',
    'barca-tv-spain'       : '522',
    'teledeporte'          : '529',
    # ITALY
    'rai-1'                : '850',
    'rai-2'                : '851',
    'rai-3'                : '852',
    'rai-sport'            : '882',
    'sky-sport-uno-italy'  : '461',
    'sky-sport-24'         : '869',
    'sky-sport-calcio'     : '870',
    'sky-sport-f1-italy'   : '577',
    'sky-calcio-1'         : '871',
    'sky-calcio-2'         : '872',
    'sky-calcio-3'         : '873',
    'dazn-zona-italy'      : '877',
    'eurosport-1-italy'    : '878',
    'eurosport-2-italy'    : '879',
    'la7'                  : '855',
    'italia-1-italy'       : '854',
    # PORTUGAL
    'sport-tv-portugal-1'  : '49',
    'sport-tv-portugal-2'  : '74',
    'sport-tv-portugal-3'  : '454',
    'sport-tv-portugal-4'  : '289',
    'sport-tv-portugal-5'  : '290',
    'eleven-sports-1-portugal': '455',
    'eleven-sports-2-portugal': '456',
    'eleven-sports-3-portugal': '457',
    'benfica-tv-pt'        : '380',
    'sporting-tv-portugal' : '716',
    'canal-11-portugal'    : '540',
    'rtp-1'                : '719',
    'rtp-3'                : '721',
    'sic-portugal'         : '722',
    'tvi'                  : '723',
    'cmtv-portugal'        : '790',
    # GERMANY
    'zdf'                  : '727',
    'sat1-de'              : '729',
    'prosieben'            : '730',
    'rtl'                  : '740',
    'sky-sport-bundesliga-1': '558',
    'sky-sport-bundesliga-2': '946',
    'sky-sports-de-1'      : '240',
    'sky-sports-f1-1-alt1' : '274',
    'dazn-1-bar-de'        : '426',
    'dazn-2-bar-de'        : '427',
    'sport1-germany'       : '641',
    'arte-de'              : '725',
    '3sat'                 : '726',
    # POLAND
    'polsat-sport-poland'  : '47',
    'canal-plus-sport-poland': '48',
    'canal-plus-sport-2-poland': '73',
    'eleven-sports-1-poland': '71',
    'eleven-sports-2-poland': '72',
    'eleven-sports-3-poland': '428',
    'eurosport-1-poland'   : '57',
    'tvp-sport'            : '128',
    'tvp1'                 : '560',
    'tvn24'                : '444',
    'polsat-news'          : '443',
    # ROMANIA
    'digi-sport-1-romania' : '400',
    'digi-sport-2-romania' : '401',
    'digi-sport-3-romania' : '402',
    'digi-sport-4-romania' : '403',
    'prima-sport-1'        : '583',
    'prima-sport-2'        : '584',
    'orange-sport-romania-1': '439',
    'orange-sport-romania-2': '440',
    # SERBIA / BALKANS
    'arena-sport-1-serbia' : '429',
    'arena-sport-2-serbia' : '430',
    'arena-sport-3-serbia' : '431',
    'arena-sport-4-serbia' : '581',
    'arena-sport-5-serbia' : '940',
    'sport-klub-serbia-1'  : '101',
    'sport-klub-serbia-2'  : '102',
    'sport-klub-serbia-3'  : '103',
    'nova-sport-serbia'    : '582',
    'arena-sport-1-croatia': '432',
    'arena-sport-2-croatia': '433',
    'max-sport-croatia-1'  : '779',
    # GREECE
    'nova-sports-greece-1' : '631',
    'nova-sports-greece-2' : '632',
    'nova-sports-greece-3' : '633',
    'nova-sports-greece-4' : '634',
    'nova-sports-greece-5' : '635',
    'nova-sports-premier-league-greece': '599',
    'cosmote-sport-1-hd'   : '622',
    'cosmote-sport-2-hd'   : '623',
    'cosmote-sport-3-hd'   : '624',
    'eurosport-1-greece'   : '41',
    # MIDDLE EAST / ARAB
    'bein-sports-mena-english-1': '61',
    'bein-sports-mena-english-2': '90',
    'bein-sports-1-arabic' : '91',
    'bein-sports-2-arabic' : '92',
    'bein-sports-3-arabic' : '93',
    'bein-sports-4-arabic' : '94',
    'alkass-one'           : '781',
    'alkass-two'           : '782',
    'abu-dhabi-sports-1-uae': '600',
    'abu-dhabi-sports-2-uae': '601',
    'dubai-sports-1-uae'   : '604',
    'dubai-sports-2-uae'   : '605',
    'ssc-sport-1'          : '614',
    'ssc-sport-2'          : '615',
    'ssc-sport-3'          : '616',
    'ontime-sports'        : '611',
    # TURKEY
    'bein-sports-1-turkey' : '62',
    'bein-sports-2-turkey' : '63',
    'bein-sports-3-turkey' : '64',
    'bein-sports-4-turkey' : '67',
    'trt-spor-tr'          : '889',
    'a-spor-turkey'        : '1011',
    'atv-turkey'           : '1000',
    # AFRICA / SOUTH AFRICA
    'supersport-grandstand': '412',
    'supersport-premier-league': '414',
    'supersport-laliga'    : '415',
    'supersport-football'  : '56',
    'supersport-rugby'     : '421',
    'supersport-cricket'   : '368',
    'supersport-psl'       : '413',
    'supersport-variety-1' : '416',
    'supersport-variety-2' : '417',
    # CANADA
    'tsn'                  : '111',
    'tsn2'                 : '112',
    'tsn3'                 : '113',
    'tsn4'                 : '114',
    'tsn5'                 : '115',
    'sportsnet-ontario'    : '406',
    'sportsnet-world'      : '410',
    'tva-sports-1'         : '833',
    'rds-2'                : '839',
    'ctv-canada'           : '602',
    'cbc-ca'               : '832',
    # BRAZIL
    'sportv-brasil-1'      : '78',
    'sportv-brasil-2'      : '79',
    'espn-brasil'          : '81',
    'tnt-brasil'           : '87',
    'combate-brasil'       : '89',
    # ARGENTINA / LATAM
    'espn-argentina'       : '149',
    'espn2-argentina'      : '150',
    'tyc-sports'           : '746',
    'tnt-sports-argentina' : '388',
    'las-estrellas'        : '924',
    'espn-1-mx'            : '925',
    'fox-sports-1-mx'      : '929',
    'tudn-mx'              : '935',
    'claro-sports-mx'      : '933',
    # INDIA / PAKISTAN
    'star-sports'          : '267',
    'sony-ten-1'           : '885',
    'sony-ten-2'           : '886',
    'sony-ten-3'           : '887',
    'ptv-sports'           : '450',
    'a-sport-pk'           : '269',
    # AUSTRALIA / NZ
    'fox-cricket'          : '369',
    'fox-sports-502-au'    : '820',
    'fox-sports-503-au'    : '821',
    'fox-sports-504-au'    : '822',
    'sky-sport-nz-1'       : '588',
    'sky-sport-nz-2'       : '589',
    'sky-sport-nz-3'       : '590',
    'bein-sports-1-australia': '491',
    'bein-sports-2-australia': '492',
    # DENMARK / SWEDEN
    'dr1-denmark'          : '801',
    'tv2-sport'            : '810',
    'tv3-sport'            : '809',
    'tv4-sportkanalen'     : '707',
    'tv4-sport-live-4'     : '703',
    'eurosport-1-sw'       : '231',
    # RUSSIA
    'match-tv'             : '127',
    'match-football-1'     : '136',
    'match-football-2'     : '137',
    'match-premier'        : '573',
    # ISRAEL
    'sport-5-israel'       : '144',
    'sport-5-live-israel'  : '146',
    'sport-1-israel'       : '140',
    'one-hd-israel-1'      : '541',
    'channel-12-israel'    : '549',
    'channel-13-israel'    : '551',
}


# ── Resolver ──────────────────────────────────────────────────────────────────

class Tv247(CommonResolver):
    """
    Resolver per tv247us.live.

    Viene invocato da SportResolver quando l'URL contiene uno dei domini
    dichiarati in tv247.json  (tv247us.live  oppure  chat.cfbu247.sbs).

    L'utente inserisce nell'XML del proprio addon uno dei seguenti formati:
      https://tv247us.live/embed/cnn-usa
      https://tv247us.live/embed/event-channel-3
    """

    def set_request_headers(self):
        self.request_headers = {
            'User-Agent': USER_AGENT,
            'Referer'   : REFERER,
            'Origin'    : 'https://tv247us.live',
        }

    # ── helpers privati ──────────────────────────────────────────────────────

    def _slug_from_url(self, url):
        """Estrae lo slug dall'URL embed, es. 'cnn-usa'."""
        m = re.search(r'/embed/([^/?#]+)', url)
        return m.group(1) if m else None

    def _channel_id_from_slug(self, slug):
        """Slug → channel_id.  event-channel-N → N."""
        if not slug:
            return None
        m = re.match(r'^event-channel-(\d+)$', slug)
        if m:
            return m.group(1)
        return CHANNELS.get(slug)

    def _call_api(self, channel_id):
        """
        Chiama l'API e restituisce l'URL m3u8 oppure stringa vuota.
        Usa self.resolver.cli (HttpClient del SportResolver) — no Tor.
        """
        api_url = API_BASE.format(channel_id=channel_id)
        try:
            resp = self.resolver.cli.get_request(api_url, headers=HEADERS_API)
            text = resp.text if hasattr(resp, 'text') else ''
            if not text:
                return ''
            data = json.loads(text)
            return (data.get('proxyPlaylistUrl')
                    or data.get('proxyPlayerUrl')
                    or data.get('m3u8_link')
                    or data.get('stream')
                    or data.get('url')
                    or '')
        except Exception:
            return ''

    # ── interfaccia CommonResolver ────────────────────────────────────────────

    def find_stream(self):
        """
        Punto di ingresso chiamato da SportResolver.find_custom_stream_url().
        Deve restituire una lista di URL (già con header pipe-separati)
        oppure lista vuota se la risoluzione fallisce.
        """
        url = self.page_url or ''

        slug       = self._slug_from_url(url)
        channel_id = self._channel_id_from_slug(slug)

        if not channel_id:
            return []

        m3u8 = self._call_api(channel_id)
        if not m3u8:
            return []

        ua = self.resolver.cli.headers.get('user-agent', USER_AGENT)
        stream = (m3u8
                  + '|Referer=' + REFERER
                  + '&User-Agent=' + ua.replace(' ', '%20'))

        return [stream]

    def set_referer(self, url):
        ua = self.resolver.cli.headers.get('user-agent', USER_AGENT)
        return ('!Referer=' + REFERER
                + '&Origin=https://tv247us.live'
                + '&User-Agent=' + ua.replace(' ', '%20'))
