import re
import base64
import json
import math
from urllib.parse import urlparse, urljoin
from conf.common import CommonResolver


class Calcio(CommonResolver):

    def __init__(self, resolver):
        super().__init__(resolver)
        self.ref = None

    # ──────────────────────────────────────────────────────────────────────
    # Punto di ingresso principale
    # ──────────────────────────────────────────────────────────────────────
    def find_stream(self):
        """
        Segue fino a 2 livelli di iframe:
          Livello 1 → es. calciolive.top/live/X.php
          Livello 2 → es. meritend.net/e/TOKEN  (usa window._econfig)
        """
        # ── Livello 1 ────────────────────────────────────────────────────
        iframe_url = self._extract_iframe_src(self.page_src, base_url=None)
        if not iframe_url:
            return []

        res1 = self.resolver.cli.get_request(iframe_url)
        self.ref = res1.url

        # Prova m3u8 diretto nel livello 1
        url = self._find_m3u8_direct(res1.text)
        if url:
            return [("Video", url)]

        # Prova _econfig nel livello 1 (a volte già qui)
        url = self._decode_econfig_from_page(res1.text)
        if url:
            return [("Video", url)]

        # ── Livello 2 ────────────────────────────────────────────────────
        iframe_url2 = self._extract_iframe_src(res1.text, base_url=res1.url)
        if not iframe_url2:
            return []

        res2 = self.resolver.cli.get_request(iframe_url2)
        self.ref = res2.url

        # Prova m3u8 diretto nel livello 2
        url = self._find_m3u8_direct(res2.text)
        if url:
            return [("Video", url)]

        # Prova _econfig nel livello 2 (meritend.net e simili)
        url = self._decode_econfig_from_page(res2.text)
        if url:
            return [("Video", url)]

        return []

    # ──────────────────────────────────────────────────────────────────────
    # Helper: URL referer/origin per il player
    # ──────────────────────────────────────────────────────────────────────
    def set_referer(self, url):
        parsed = urlparse(self.ref)
        origin = "{0}://{1}".format(parsed.scheme, parsed.netloc)
        ua = self.resolver.cli.headers["user-agent"]
        return "!Referer={0}&Origin={1}&User-Agent={2}".format(
            self.ref, origin, ua)

    # ──────────────────────────────────────────────────────────────────────
    # Utilità private
    # ──────────────────────────────────────────────────────────────────────
    @staticmethod
    def _extract_iframe_src(html, base_url):
        """
        Estrae il primo src di <iframe>.
        Gestisce virgolette singole/doppie e URL relativi.
        """
        m = re.search(
            r'<iframe[^>]+\bsrc\s*=\s*["\']([^"\']+)["\']',
            html, re.IGNORECASE | re.DOTALL)
        if not m:
            return None
        src = m.group(1).strip()
        if src.startswith("//"):
            return "https:" + src
        if src.startswith("/") and base_url:
            return urljoin(base_url, src)
        if not src.startswith("http") and base_url:
            return urljoin(base_url, src)
        return src

    @staticmethod
    def _find_m3u8_direct(html):
        """Cerca un URL .m3u8 direttamente nell'HTML."""
        m = re.search(
            r'["\'](\s*https?://[^"\']+\.m3u8[^"\']*)["\']',
            html, re.IGNORECASE)
        return m.group(1).strip() if m else None

    @staticmethod
    def _decode_econfig_from_page(html):
        """
        Cerca window._econfig nell'HTML e lo decodifica con l'algoritmo
        di stream.js (_0x27c180), reverse-engineered da meritend.net.
        """
        m = re.search(
            r"""window\._econfig\s*=\s*['"]([A-Za-z0-9+/=]+)['"]""",
            html)
        if not m:
            return None
        return Calcio._decode_econfig(m.group(1))

    @staticmethod
    def _decode_econfig(b64_str):
        """
        Replica esatta di _0x27c180() da stream.js (meritend.net):

          1. atob(econfig)               → ~106K chars di base64 interni
          2. Divide in 4 chunk uguali (ceil)
          3. Per ogni chunk i:
               a. Rimuove il char all'indice 3  (disturbo intenzionale)
               b. atob(chunk_modificato)        → binary
          4. Riordina con permutazione [2, 0, 3, 1]
          5. Join degli slot 0‥3
          6. atob(joined)               → JSON bytes
          7. JSON.parse → estrae stream_url / src / url

        Algoritmo ottenuto dal reverse-engineering di stream_debug.js:
          - _0x5f3146(0x1da) = 'substr'
          - _0x5f3146(0x1b4) = 'slice'
          - _0x5f3146(0x160) = 'join'
          - permutation      = [2, 0, 3, 1]
        """
        def _atob(s):
            """Equivalente di atob JS: filtra non-b64, decodifica."""
            if isinstance(s, (bytes, bytearray)):
                s = s.decode('latin-1')
            clean = re.sub(r'[^A-Za-z0-9+/=]', '', s)
            if not clean:
                return b''
            pad = (4 - len(clean) % 4) % 4
            return base64.b64decode(clean + '=' * pad)

        try:
            # Step 1 – atob(econfig)
            decoded = _atob(b64_str).decode('latin-1')
            n = len(decoded)
            chunk_size = math.ceil(n / 4)

            # Step 2 – split in 4 chunk via substr(start, length)
            parts = [decoded[i * chunk_size:(i + 1) * chunk_size]
                     for i in range(4)]

            # Step 3 – rimuovi char[3], poi atob
            perm = [2, 0, 3, 1]
            slots = [None] * 4
            for i in range(4):
                modified = parts[i][:3] + parts[i][4:]   # rimuove indice 3
                slots[perm[i]] = _atob(modified)

            # Step 4-5 – join degli slot
            joined = b''.join(slots).decode('latin-1')

            # Step 6 – atob(joined) → JSON
            config = json.loads(_atob(joined).decode('utf-8'))

            # Step 7 – estrai stream URL
            for key in ('stream_url', 'stream_url_nop2p',
                        'src', 'url', 'file', 'hls', 'source'):
                val = config.get(key, '')
                if isinstance(val, str) and val.startswith('http'):
                    return val

            # Fallback: primo valore HTTP nel dict
            for val in config.values():
                if isinstance(val, str) and val.startswith('http'):
                    return val

        except Exception:
            pass

        return None
