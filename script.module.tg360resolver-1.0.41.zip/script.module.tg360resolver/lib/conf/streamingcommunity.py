import logging
import re
import time
from urllib.parse import quote_plus

from conf.common import CommonResolver

logger = logging.getLogger(__name__)

TELEGRAPH_URL = "https://telegra.ph/Link-Aggiornato-StreamingCommunity-09-29"

# Risultato dell'ultima lettura della pagina telegra.ph, valido _TTL secondi
# (anche se la lettura e' fallita: evita di riprovare, e di aspettare il
# timeout, ad ogni singola risoluzione).
_SERVER_CACHE = {"ts": 0.0, "href": None}
_SERVER_CACHE_TTL = 600


class StreamCommunity(CommonResolver):
    def __init__(self, resolver):
        super().__init__(resolver)
        self.use_last_domain = True
        self.ref = ''
        self.get_server()

    def find_stream(self):
        iframe_url = re.compile(r'embedUrl.*?;(http.*?)&quot;', re.MULTILINE | re.DOTALL).findall(self.page_src)

        if iframe_url:
            self.page_url = iframe_url[0].replace('\\/', '/').replace('&amp;', '&')

        page_src = self.resolver.cli.get_request(self.page_url)
        matches = re.compile(r'ref="iframe".*?src="([^"]+)"', re.MULTILINE | re.DOTALL).findall(page_src.text)
        
        if matches:
            url = matches[0].replace('\\/', '/').replace('&amp;', '&')
            r = self.resolver.cli.get_request(url,
                                              headers={'referer': self.resolver.find_hostname(
                                                  self.page_url) + "/"})

            ms = re.compile(r"window.masterPlaylist = ({.*?params:.*?{.*?},.*?})", re.DOTALL) \
                .findall(r.text)
            self.ref = url

            if ms:
                masterplaylist = ms[0]
                mediaurl = re.compile(r"url: '([^']+)'", re.MULTILINE).findall(masterplaylist)[0]
                if "?" not in mediaurl:
                    mediaurl += "?"
                else:
                    mediaurl += "&"
                ps = re.compile(r".*?'([^']+)':.*?'(.*?)'(?:,|$)", re.MULTILINE | re.DOTALL).findall(masterplaylist)
                for p in ps:
                    k, v = p
                    if v == "": continue
                    mediaurl += k + "=" + v + "&"
                mediaurl = mediaurl.rstrip("&")

                if "canPlayFHD" in url:
                    mediaurl += "&h=1"

                mediaurl += "&scz=1&lang=it"

                return [mediaurl]

        return []

    def set_referer(self, url):
        return "!Referer=" + quote_plus(self.ref) + "&User-Agent=" + self.resolver.cli.headers["user-agent"] + "&force_isaf=1&isaf_rts=false"

    def get_server(self):
        # Prima la pagina veniva scaricata ad OGNI risoluzione, anche di URL che
        # non c'entrano con StreamingCommunity, e se telegra.ph non rispondeva
        # l'eccezione faceva fallire tutto SportResolver(). Ora: cache breve,
        # timeout corto, errori ignorati.
        now = time.time()
        if now - _SERVER_CACHE["ts"] > _SERVER_CACHE_TTL:
            href = None
            try:
                r = self.resolver.cli.get_request(TELEGRAPH_URL, timeout=5)
                found = re.compile(r"address><p><a href=\"([^\"]+)\"", re.MULTILINE).findall(r.text)
                href = found[0] if found else None
            except Exception as e:
                logger.warning("StreamingCommunity: telegra.ph non raggiungibile: %s", e)
            _SERVER_CACHE["ts"] = now
            _SERVER_CACHE["href"] = href

        server = _SERVER_CACHE["href"]
        if server and server not in self.servers:
            server = re.sub(r'http.*?://(.*?)/', "\\1", server, 0, re.MULTILINE)
            self.servers.append(server + "/it")
