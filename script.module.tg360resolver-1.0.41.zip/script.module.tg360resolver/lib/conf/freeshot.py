# -*- coding: utf-8 -*-
"""
lib/conf/freeshot.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Resolver per freeshot.live / airhdx.com e CDN correlati
integrato in script.module.tg360resolver.

Gestisce i link di tipo <sublink type="resolve"> provenienti dall'XML
dell'addon, tra cui:
  - https://www.airhdx.com/embed.php?live=...
  - https://www.freeshot.live/embed/*.php
  - https://popcdn.day/stream/*.php
  - http://.../*.m3u8   (passthrough diretto)
  - http://host:port/path/stream.m3u8  (IPTV diretto)

Catena di risoluzione:
  1. Se il link e' gia' un .m3u8 → restituisce direttamente
  2. GET pagina embed → cerca m3u8 / iframe CDN nell'HTML
  3. GET CDN iframe (popcdn.day / lovetier.bz) → cerca m3u8
  4. Terzo livello iframe annidato → cerca m3u8
"""

import re
from urllib.parse import urlparse, unquote

from conf.common import CommonResolver

# ──────────────────────────────────────────────────────────────────────
# COSTANTI
# ──────────────────────────────────────────────────────────────────────

_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

# iframe pubblicitari / tracker da ignorare
_IFRAME_SKIP = (
    "facebook.com", "twitter.com", "google.com", "doubleclick",
    "disqus.com", "recaptcha", "googlesyndication", "googletagmanager",
    "adnxs.com", "amazon-adsystem", "alwingulla.com", "aiscore.com",
    "/ads/", "histats.com", "/point.php", "mc.yandex", "hotjar",
    "scorecard", "quantserve", "chartbeat", "comscore",
    "endlesshandbaglinked.com", "chatango.com",
)


# ──────────────────────────────────────────────────────────────────────
# CLASSE RESOLVER
# ──────────────────────────────────────────────────────────────────────

class Freeshot(CommonResolver):
    """
    Resolver per freeshot.live, airhdx.com e CDN correlati.

    Viene invocato da SportResolver quando il link XML corrisponde
    a uno dei domini in freeshot.json.
    """

    def __init__(self, resolver):
        super().__init__(resolver)
        self.ref = None  # URL finale dell'iframe che ha restituito l'm3u8

    # ──────────────────────────────────────────────────────────────────
    # set_request_headers: header base per tutte le richieste
    # ──────────────────────────────────────────────────────────────────
    def set_request_headers(self):
        self.request_headers = {
            "User-Agent": _UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
        }

    # ──────────────────────────────────────────────────────────────────
    # find_stream: punto di ingresso chiamato da SportResolver
    # self.page_url  = URL originale del link XML
    # self.page_src  = HTML della pagina già scaricata da SportResolver
    # ──────────────────────────────────────────────────────────────────
    def find_stream(self):
        url = self.page_url or self.resolver.start_url

        # ── 0. Link .m3u8 / .mpd diretto → passthrough ───────────────
        if self._is_stream_url(url):
            self.ref = url
            return [url]

        # ── 1. Cerca player nell'HTML già disponibile (embed page) ────
        html = self.page_src or ""
        if html:
            result = self._search_player(html, url)
            if result:
                return [result]

        # ── 2. Se non trovato (o page_src vuoto) scarica l'URL ────────
        try:
            hdrs = {"Referer": self._origin(url) + "/", "User-Agent": _UA}
            res = self.resolver.cli.get_request(url, headers=hdrs)
            html = res.text
            url  = res.url
        except Exception:
            return []

        result = self._search_player(html, url)
        if result:
            return [result]

        return []

    # ──────────────────────────────────────────────────────────────────
    # set_referer: header da allegare all'm3u8 per Kodi
    # ──────────────────────────────────────────────────────────────────
    def set_referer(self, url):
        ref = self.ref or self._origin(self.resolver.start_url) + "/"
        origin = self._origin(ref)
        ua = self.resolver.cli.headers.get("user-agent", _UA)
        return "!Referer={0}&Origin={1}&User-Agent={2}".format(ref, origin, ua)

    # ──────────────────────────────────────────────────────────────────
    # LOGICA INTERNA
    # ──────────────────────────────────────────────────────────────────

    def _search_player(self, html, base_url):
        """
        Cerca l'm3u8 nell'HTML (fino a 3 livelli di iframe).
        Restituisce l'URL stringa oppure None.
        """
        # Livello 1: HTML embed diretto
        kind, value = self._find_player(html)

        if kind == "m3u8":
            self.ref = base_url
            return value

        if kind == "iframe":
            # Livello 2: CDN (popcdn.day, lovetier.bz, …)
            cdn_html, cdn_url = self._fetch(value, referer=base_url)
            if cdn_html:
                kind2, value2 = self._find_player(cdn_html)
                if kind2 == "m3u8":
                    self.ref = cdn_url
                    return value2
                if kind2 == "iframe":
                    # Livello 3: iframe annidato
                    l3_html, l3_url = self._fetch(value2, referer=cdn_url)
                    if l3_html:
                        kind3, value3 = self._find_player(l3_html)
                        if kind3 == "m3u8":
                            self.ref = l3_url
                            return value3

        # Fallback: deoffuscazione script freeshot.live
        html2 = self._deobfuscate_scripts(html)
        if html2 != html:
            kind, value = self._find_player(html2)
            if kind == "m3u8":
                self.ref = base_url
                return value
            if kind == "iframe":
                cdn_html, cdn_url = self._fetch(value, referer=base_url)
                if cdn_html:
                    kind2, value2 = self._find_player(cdn_html)
                    if kind2 == "m3u8":
                        self.ref = cdn_url
                        return value2

        return None

    def _find_player(self, html):
        """
        Cerca pattern player in un blocco HTML/JS.
        Restituisce (kind, value): kind in {'m3u8', 'iframe'} o (None, None).
        """
        clean = html.replace("\\/", "/")

        # ── 1. Iframe embed freeshot.live ──────────────────────────────
        for src in re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE):
            src = self._abs(src)
            if self._is_ad(src):
                continue
            if "freeshot.live/embed" in src.lower():
                return ("iframe", src)

        # ── 2. Iframe CDN popcdn.day ───────────────────────────────────
        for src in re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE):
            src = self._abs(src)
            if self._is_ad(src):
                continue
            if "popcdn.day" in src.lower():
                return ("iframe", src)

        # ── 3. m3u8 diretto ───────────────────────────────────────────
        for text in (clean, html):
            m = re.search(
                r'["\']?(https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)["\']?',
                text, re.IGNORECASE
            )
            if m:
                return ("m3u8", m.group(1).replace("\\/", "/"))

        # ── 4. Clappr source: "…m3u8" ─────────────────────────────────
        m = re.search(
            r'source\s*:\s*["\']((https?://)[^"\']+\.m3u8[^"\']*)["\']',
            clean, re.IGNORECASE
        )
        if m:
            return ("m3u8", m.group(1))

        # ── 5. jwplayer/videojs file/source ───────────────────────────
        for pat in [
            r'(?:file|source|src)\s*:\s*["\']([^"\']+\.m3u8[^"\']*)["\']',
            r'(?:file|source)\s*:\s*["\']([^"\']+)["\']',
        ]:
            m = re.search(pat, html, re.IGNORECASE)
            if m and any(kw in m.group(1) for kw in ("stream", "m3u8", "http")):
                val = m.group(1)
                if val.startswith("http"):
                    return ("m3u8" if ".m3u8" in val else "iframe", val)

        # ── 6. streamUrl / hlsUrl JS global ───────────────────────────
        for pat in [
            r'(?:window\.)?(?:streamUrl|hlsUrl|streamSrc|videoUrl)\s*=\s*["\']([^"\']+)["\']',
            r'"(?:stream_url|hls_url|video_url)"\s*:\s*"([^"]+)"',
        ]:
            m = re.search(pat, html, re.IGNORECASE)
            if m:
                val = m.group(1)
                return ("m3u8", val) if ("m3u8" in val or val.startswith("http")) else ("iframe", val)

        # ── 7. lovetier.bz player ─────────────────────────────────────
        m = re.search(r'["\']((https?:)?//lovetier\.bz/player/[^"\']+)["\']', html, re.IGNORECASE)
        if m:
            src = m.group(1)
            if src.startswith("//"):
                src = "https:" + src
            return ("iframe", src)

        # ── 8. Altri iframe generici (non-ad) ─────────────────────────
        for src in re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE):
            src = self._abs(src)
            if self._is_ad(src):
                continue
            if src.startswith("http"):
                return ("iframe", src)

        return (None, None)

    # ──────────────────────────────────────────────────────────────────
    # DEOFFUSCAZIONE SCRIPT freeshot.live (schema 2024+)
    # ──────────────────────────────────────────────────────────────────

    def _deobfuscate_scripts(self, html):
        """
        Estrae e deoffusca tutti gli script che usano decodeURI(…)
        con il cipher rotante freeshot.live.
        Restituisce l'HTML originale + i testi deoffuscati concatenati.
        """
        result = html
        scripts = re.findall(r'<script[^>]*>(.*?)</script>', html, re.IGNORECASE | re.DOTALL)
        for script in scripts:
            if 'decodeURI(' not in script:
                continue
            decoded = self._deobfuscate_new(script)
            if decoded:
                result += "\n" + decoded
            else:
                decoded = self._deobfuscate_old(script)
                if decoded:
                    result += "\n" + decoded
        return result

    @staticmethod
    def _deobfuscate_new(script_text):
        """Schema 2024+: rotating shift cipher mod 95."""
        m = re.search(r'decodeURI\("([^"]+)"\)', script_text)
        if not m:
            return ""
        try:
            decoded = unquote(m.group(1))
            decoded = re.sub(r'(@)\1+', r'\1', decoded)
            chars = list(decoded)
            out = []
            for t, ch in enumerate(chars):
                code = ord(ch) - 32
                if 0 <= code < 95:
                    out.append(chr(32 + (code + t) % 95))
                else:
                    out.append(ch)
            return "".join(out)
        except Exception:
            return ""

    @staticmethod
    def _deobfuscate_old(script_text):
        """Schema legacy: shift fisso r%9."""
        m = re.search(r'decodeURI\("([^"]+)"\)', script_text)
        if not m:
            return ""
        if not re.search(r'charCodeAt\s*\(\s*\w+\s*\)\s*-\s*\w+\s*%\s*9', script_text):
            return ""
        try:
            decoded = unquote(m.group(1))
            shift = len(decoded) % 9
            return "".join(chr(max(32, ord(c) - shift)) for c in decoded)
        except Exception:
            return ""

    # ──────────────────────────────────────────────────────────────────
    # UTILITÀ
    # ──────────────────────────────────────────────────────────────────

    def _fetch(self, url, referer=None):
        """Scarica url con headers corretti. Restituisce (html, final_url)."""
        try:
            hdrs = {"User-Agent": _UA, "Accept": "text/html,*/*"}
            if referer:
                hdrs["Referer"] = referer
                hdrs["Origin"] = self._origin(referer)
            res = self.resolver.cli.get_request(url, headers=hdrs)
            if res.status_code < 400:
                return res.text, res.url
        except Exception:
            pass
        return "", url

    @staticmethod
    def _is_stream_url(url):
        """True se l'URL è già un link stream riproducibile direttamente."""
        u = url.lower()
        return (
            ".m3u8" in u or
            ".mpd" in u or
            (re.match(r'https?://[^/]+:\d+/', url) and u.endswith((".ts", ".m3u8")))
        )

    @staticmethod
    def _is_ad(src):
        """True se il src dell'iframe è pubblicitario/tracker."""
        low = src.lower()
        return any(x in low for x in _IFRAME_SKIP)

    @staticmethod
    def _abs(src):
        """Normalizza URL relativi con schema //."""
        if src.startswith("//"):
            return "https:" + src
        return src

    @staticmethod
    def _origin(url):
        """Estrae scheme://host dall'URL."""
        try:
            p = urlparse(url)
            return "{0}://{1}".format(p.scheme, p.netloc)
        except Exception:
            return url
