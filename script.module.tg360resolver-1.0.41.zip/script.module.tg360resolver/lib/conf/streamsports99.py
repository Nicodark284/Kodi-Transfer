import re
import base64
from conf.common import CommonResolver

class Streamsports99(CommonResolver):
    def __init__(self, resolver):
        super().__init__(resolver)
        self.ref = None

    def compose_string(self, stringa):
        stringa_corretta = stringa.replace('-', '+').replace('_', '/')
        padding = len(stringa_corretta) % 4
        if padding:
            stringa_corretta += '=' * (4 - padding)
        byte_data = base64.b64decode(stringa_corretta)
        try:
            return byte_data.decode('utf-8')
        except:
            return byte_data.decode('latin-1')

    def find_stream(self):
        url_target = self.resolver.start_url
        if not url_target or "cdnlivetv.tv" not in url_target:
            return []

        r = self.resolver.cli.get_request(url_target)
        
        base64_vars = re.findall(r"var\s+[a-zA-Z0-9_]+\s*=\s*'([A-Za-z0-9+/=\-_]+)'\s*;", r.text)
        
        if base64_vars:
            url = ""
            for encoded_chunk in base64_vars:
                url += self.compose_string(encoded_chunk)
            
            if url.startswith("http"):
                clean_match = re.match(r'(https?://[^\s\?]+\?token=[A-Za-z0-9]+)', url)
                if clean_match:
                    clean_url = clean_match.group(1)
                    return [clean_url]
                
                clean_url = url.split('\x7f')[0].split('\x00')[0].strip()
                return [clean_url]
        
        return []

    def set_referer(self, url):
        ref = "https://cdnlivetv.tv"
        return "|Referer=" + ref + "/"
