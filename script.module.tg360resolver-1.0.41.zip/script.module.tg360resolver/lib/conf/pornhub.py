"""
    PornHub resolver per tg360resolver
    Adattato dal plugin ResolveURL originale di gujal
    e dal plugin Cumination (Whitecream / anton40)
"""

import re
import json

from conf.common import CommonResolver


class Pornhub(CommonResolver):
    """
    Resolver per URL PornHub (pornhub.com).
    Supporta:
      - /view_video.php?viewkey=ID
      - /embed/ID

    Tre strategie di estrazione (stessa logica di ResolveURL):
      1. qualityItems_* JSON array (metodo moderno)
      2. var ra* deobfuscation (metodo legacy)
      3. flashvars_* JSON object (metodo fallback)
    """

    def _build_headers(self):
        try:
            ua = self.resolver.cli.get_random_ua()
        except Exception:
            ua = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                  'AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/120.0.0.0 Safari/537.36')
        return {
            'User-Agent': ua,
            'Referer': 'https://www.pornhub.com/',
            'Cookie': 'accessAgeDisclaimerPH=1; accessAgeDisclaimerUK=1',
        }

    def _get_media_id(self):
        """Estrae il viewkey dall'URL della pagina."""
        for text in (self.page_url or '', self.page_src or ''):
            # /view_video.php?viewkey=XXXXX  oppure  /embed/XXXXX
            m = re.search(
                r'pornhub\.com/(?:view_video\.php\?viewkey=|embed/)([a-zA-Z0-9]+)',
                text
            )
            if m:
                return m.group(1)
        return None

    def _fetch_page(self):
        """Scarica la pagina video se non già disponibile in self.page_src."""
        if self.page_src:
            return self.page_src
        media_id = self._get_media_id()
        if not media_id:
            return ''
        url = 'https://www.pornhub.com/view_video.php?viewkey={}'.format(media_id)
        try:
            r = self.resolver.cli.get_request(url, headers=self._build_headers())
            return r.text
        except Exception:
            return ''

    # ------------------------------------------------------------------
    # Strategia 1 – qualityItems_* (metodo moderno)
    # ------------------------------------------------------------------
    def _method_quality_items(self, html):
        m = re.search(r'qualityItems_[^\[]+(\[.+?\]);', html)
        if not m:
            return []
        try:
            items = json.loads(m.group(1))
            return [(src.get('text', ''), src.get('url', ''))
                    for src in items if src.get('url')]
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Strategia 2 – var ra* deobfuscation (metodo legacy)
    # ------------------------------------------------------------------
    def _method_ra_vars(self, html):
        sources = []
        sections = re.findall(r'(var\sra[a-z0-9]+=.+?);flash', html)
        for section in sections:
            try:
                pvars = re.findall(r'var\s(ra[a-z0-9]+)=([^;]+)', section)
                link_match = re.findall(r'var\smedia_\d+=([^;]+)', section)
                if not link_match:
                    continue
                link = link_match[0]
                link = re.sub(r'/\*.+?\*/', '', link)
                for key, value in pvars:
                    link = re.sub(key, value, link)
                link = link.replace('"', '').split('+')
                link = ''.join([i.strip() for i in link])
                if 'urlset' not in link:
                    r = re.findall(r'(\d+p)', link, re.I)
                    if r:
                        sources.append((r[0], link))
            except Exception:
                continue
        return sources

    # ------------------------------------------------------------------
    # Strategia 3 – flashvars_* JSON (metodo fallback)
    # ------------------------------------------------------------------
    def _method_flashvars(self, html):
        m = re.search(r'flashvars_\d+\s*=\s*(\{.+?\});\s', html)
        if not m:
            return []
        try:
            fvars = json.loads(m.group(1))
            media_defs = fvars.get('mediaDefinitions') or []
            return [(src.get('quality', ''), src.get('videoUrl', ''))
                    for src in media_defs
                    if not isinstance(src.get('quality'), list)
                    and src.get('videoUrl')]
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Scelta della qualità migliore
    # ------------------------------------------------------------------
    @staticmethod
    def _pick_best(sources):
        """Ordina per risoluzione numerica decrescente e ritorna il miglior URL."""
        def _res(label):
            if not label:
                return 0
            m = re.search(r'(\d+)', str(label))
            return int(m.group(1)) if m else 0

        # filtra url vuoti
        valid = [(q, u) for q, u in sources if u and u.startswith('http')]
        if not valid:
            return None
        valid.sort(key=lambda x: _res(x[0]), reverse=True)
        return valid[0][1].strip()

    # ------------------------------------------------------------------
    # find_stream – punto di ingresso del resolver
    # ------------------------------------------------------------------
    def find_stream(self):
        html = self._fetch_page()
        if not html:
            return []

        # Prova le tre strategie in ordine
        for method in (self._method_quality_items,
                       self._method_ra_vars,
                       self._method_flashvars):
            sources = method(html)
            if sources:
                best = self._pick_best(sources)
                if best:
                    return [best]

        return []

    def set_referer(self, url):
        """Aggiunge headers di referer/origin all'URL stream."""
        try:
            ua = self.resolver.cli.headers.get('user-agent', '')
        except Exception:
            ua = ''
        return '!Referer=https://www.pornhub.com/&Origin=https://www.pornhub.com&User-Agent=' + ua
