from conf.common import CommonResolver


class GuardaSerie(CommonResolver):
    def __init__(self, resolver):
        super().__init__(resolver)

    def get_server(self):
        pass