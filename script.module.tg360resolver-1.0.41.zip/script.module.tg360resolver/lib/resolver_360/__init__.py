import json
import os
import os.path
import re

from resolver_360.thegroove_sport_resolver import SportResolver
import logging
import xbmcaddon

logger = logging.getLogger(xbmcaddon.Addon().getAddonInfo('id'))


def resolve(url):
    sr = SportResolver(url)
    sr.find_page_src()

    if sr.resolved:
        logger.debug(sr.resolved_urls)
        return sr.resolved_urls

    return None

def get_domain_name(url):
    sr = SportResolver(url)
    return sr.get_server_name()

# Nome di un file di domini: solo "qualcosa.json" direttamente in conf/.
_DOMAINS_FILE = re.compile(r'^[A-Za-z0-9_\-]+\.json$')


def _valid_domains_doc(doc):
    return (isinstance(doc, dict) and isinstance(doc.get("domains"), list)
            and all(isinstance(d, str) for d in doc["domains"]))


def update_domains(json_content):
    """
    Riscrive i file conf/<nome>.json con i domini ricevuti dal server.

    - scrittura atomica (file temporaneo + os.replace): se il processo viene
      chiuso a meta' o la scrittura fallisce, il file esistente resta intatto
      (prima `open(..., 'w+')` lo svuotava subito);
    - contenuti non validi (null, senza "domains") ignorati: prima un null dal
      server sovrascriveva il file, e supervideo.json e' ancora cosi';
    - nomi file non validi ignorati: il nome arriva dal server e finiva in
      os.path.join(confdir, name), quindi "../x" scriveva fuori da conf/.
    """
    if not isinstance(json_content, dict):
        logger.warning("update_domains: risposta non valida (%s)", type(json_content).__name__)
        return

    confdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "conf")

    for name, content in json_content.items():
        if not _DOMAINS_FILE.match(str(name)):
            logger.warning("update_domains: nome file non valido ignorato: %r", name)
            continue
        if not _valid_domains_doc(content):
            logger.warning("update_domains: contenuto non valido per %s, ignorato", name)
            continue

        target = os.path.join(confdir, name)
        tmp = target + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as outfile:
                outfile.write(json.dumps(content))
                outfile.flush()
                os.fsync(outfile.fileno())
            os.replace(tmp, target)
        except Exception as exc:
            logger.warning("update_domains: scrittura di %s fallita: %s", name, exc)
            try:
                os.remove(tmp)
            except OSError:
                pass
